package client;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ClientHearing {

        ServerSocket serverSocket;
        ExecutorService pool;

        public ClientHearing(int port) throws IOException {
    //        System.out.println("Enter to constructor");
            serverSocket = new ServerSocket(port);
            System.out.println("Server Socket is initialized");

            pool = Executors.newFixedThreadPool(5);
        }
        public void run() throws IOException {
            while (true) {
                System.out.println("Server socket start listening");
                Socket connectionSocket = serverSocket.accept();
                System.out.println("Server Socket find a new connection");
                // TCP (IP SRC , IP DST, P

                ClientThread clientThread = new ClientThread(connectionSocket);
                pool.execute(clientThread);
            }
        }

     //   public static void main(String[] args) {
          //  try {

     //           MainServer mainServer = new MainServer();
       //         mainServer.run();

            //} //catch (IOException e) {
          //      e.printStackTrace();
            //}
      //  }


    ///////
}
