package client;

import java.io.*;
import java.net.*;

public class Client {
    DatagramSocket clientSocket;

    static int sw;
    public String ipL;
    public int portL;

    public Client( int portNumber) throws SocketException {
        clientSocket = new DatagramSocket(portNumber);

    }

    public void run() throws IOException {

        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));

        while (true){
            System.out.println("Please enter something");
            String line = consoleReader.readLine();
            line = line + " ";
            ////
            if(line.startsWith("user")){
             sw  = 1;
            }
            else if(line.startsWith("ip")){
                String[] tok= line.split(" ");
                ipL = tok[1];
            }
            else if(line.startsWith("port")){
                String[] tok= line.split(" ");
                portL = Integer.parseInt(tok[1]);
            }
            else if (line.startsWith("hear")){
                ClientHearing clientHearing = new ClientHearing(portL);
                clientHearing.run();
            }
            ///
            DatagramPacket packet = new DatagramPacket(line.getBytes(), line.getBytes().length,
                    InetAddress.getByName("localhost"), 20000);
            clientSocket.send(packet);
            //  System.out.println("clinet sends " +line);

            if(line.startsWith("exit"))
                break;


            byte[] buffer = new byte[1024];
            DatagramPacket recivedPacket = new DatagramPacket(buffer,buffer.length);
            clientSocket.receive(recivedPacket);

            System.out.println(new String(recivedPacket.getData()));
/////////////

            // start chat
            if (sw == 1 ) {
                String lineRec = new String(recivedPacket.getData());
                String[] tokensRec = lineRec.split(" ");

                String Ip = tokensRec[1];
                int Port = Integer.parseInt(tokensRec[2]);
     //           System.out.println("Ip:"+Ip);
       //         System.out.println("port:"+port);

                ClientTCP clientTCP = new ClientTCP(Ip ,Port);
                clientTCP.run();

     //            Socket connectionSocket = serverSocket.accept();

          //      ClientThread clientThread = new ClientThread(port);
   //             pool.execute(clientThread);

            }
//////////////////////
        }

        clientSocket.close();


    }
/*
    public void runTCP(String ip , int port){
        try {
            socket = new Socket("localhost",40000 );
        } catch (IOException e) {
            e.printStackTrace();
        }
        //, null , 20124);
        try {
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
///
        System.out.println("Local IP : "+socket.getLocalAddress().getHostAddress());
        System.out.println("Local Port : "+socket.getLocalPort());
        System.out.println("Remote IP : "+socket.getInetAddress().getHostAddress());
        System.out.println("Remote Port : "+socket.getPort());

        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
        while (true){
            try {
                System.out.println("Please enter something: ");
                String line = consoleReader.readLine();
                writer.write(line + "\n");
                writer.flush();
                if(line.startsWith("exit")){
                    break;
                }
                line = reader.readLine();
                System.out.println("Server Response : " + line);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            consoleReader.close();
            reader.close();
            writer.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
*/
    public static void main(String[] args) {

        sw =0;
        Client client = null;
        try {
            client = new Client(16000);
            client.run();
        }
        catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }


}
